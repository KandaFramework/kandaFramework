<?php
/**
 * @package App
 * 
 * Model
 * 
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 * @package App
 * 
 */
namespace core\app;

class Model extends \ActiveRecord\Config{}