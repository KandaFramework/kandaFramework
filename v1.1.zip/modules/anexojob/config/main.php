<?php

return $main = [
   'db' => [
        'dsn' => 'mysql://anexojob:linux321@localhost/anexojob',
    ],
];
       