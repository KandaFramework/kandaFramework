<?php

/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */

namespace anexojob\controllers;

use helps\Session;

class AnexojobController extends \app\Controller {

    public function actionIndex() {
 
     return $this->render('index');
      
    }

}