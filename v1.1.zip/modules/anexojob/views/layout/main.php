<!DOCTYPE html>
<html lang="pt BR">
<head>
    <title>Anexojob</title>
    <meta charset="utf-8">
    <meta name = "format-detection" content = "telephone=no" />
    <link rel="icon" href="<?php echo $this->assets($theme) ?>images/favicon.ico">
    <link rel="shortcut icon" href="<?php echo $this->assets($theme) ?>images/favicon.ico" />
    <link rel="stylesheet" href="<?php echo $this->assets($theme) ?>css/stuck.css">
    <link rel="stylesheet" href="<?php echo $this->assets($theme) ?>css/touchTouch.css">
    <link rel="stylesheet" href="<?php echo $this->assets($theme) ?>css/camera.css">
    <link rel="stylesheet" href="<?php echo $this->assets($theme) ?>css/style.css">

    <!--<![endif]-->



    <!--[if lt IE 8]>
    <div style=' clear: both; text-align:center; position: relative;'>
        <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
            <img src="http://storage.ie6countdown.com/assets/100/<?php echo $this->assets($theme) ?>images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
    </div>
    <![endif]-->
    <!--[if lt IE 9]>
    <script src="<?php echo $this->assets($theme) ?>js/html5shiv.js"></script>
    <link rel="stylesheet" media="screen" href="<?php echo $this->assets($theme) ?>css/ie.css">


    <![endif]-->
</head>
<body class="page1" id="top">
<!--==============================header=================================-->
<header>
    <div class="container">
        <div class="row">
            <div class="grid_12">
                <h1>
                    <a href="index.html">
                        <img src="<?php echo $this->assets($theme) ?>images/logo.png" alt="Your Happy Family">
                    </a>
                </h1>
                <div class="consult">
                    <img src="<?php echo $this->assets($theme) ?>images/consult.png" alt="">
                    Need a helping hand? Call our office search <br>
                    helpline for advice - 0800 368 0380
                </div>
                <div class="socials">
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-google-plus"></a>
                    <a href="#" class="fa fa-rss"></a>
                    <a href="#" class="fa fa-pinterest"></a>
                    <a href="#" class="fa fa-linkedin"></a>
                </div>
            </div>
        </div>
    </div>
    <div id="stuck_container">
        <div class="container">
            <div class="row">
                <div class="grid_12">
                    <div class="autor"><a href="#">Signup</a><span>  |  </span><a href="<?php echo $this->createUrl('chamado') ?>">Chamado</a></div>
                    <div class="menu_block ">
                        <nav class="horizontal-nav full-width horizontalNav-notprocessed">
                            <ul class="sf-menu">
                                <li class="current"><a href="index.html">Home</a></li>
                                <li><a href="index-1.html">Sobre</a>
                                    <ul>
                                        <li><a href="#">História</a></li>
                                        <li><a href="#">testimonials</a></li>
                                    </ul>
                                </li>
                                <li><a href="index-2.html">Planos e serviços</a></li>
                                <li><a href="index-3.html">Estrutura</a></li>
                                <li><a href="index-4.html">Localização</a></li>
                                <li><a href="index-5.html">Contato</a></li>
                            </ul>
                        </nav>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>

                </div>
            </div>
        </div>
    </div>
</header>
<div class="slider_wrapper ">
    <div id="camera_wrap" class="">
        <div data-src="<?php echo $this->assets($theme) ?>images/slide.jpg">
            <div class="caption fadeIn">
                <h2><span>We'll find</span>your dream</h2>
                office in minutes
            </div>
        </div>
        <div data-src="<?php echo $this->assets($theme) ?>images/slide1.jpg">
            <div class="caption fadeIn">
                <h2><span>Free access</span>to offices for</h2>
                rent listings
            </div>
        </div>
        <div data-src="<?php echo $this->assets($theme) ?>images/slide2.jpg">
            <div class="caption fadeIn">
                <h2><span>Affordable office</span>spaces for your</h2>
                particular needs
            </div>
        </div>
    </div>
</div>
<div class="page1_block">
    <div class="container">
        <div class="row">
            <div class="grid_3">
                <div class="round">6,915</div>
                <div class="text1">Spare desks in shared offices</div>Average cost/mth
                <div class="price col1">$262/person </div>
                from $59/person
                <br>
                <a href="#" class="btn">More</a>
            </div>
            <div class="grid_3">
                <div class="round">177,85</div>
                <div class="text1">Desks to rent in serviced offices</div>Average cost/mth
                <div class="price col1">$320/person </div>
                from $53/person
                <br>
                <a href="#" class="btn">More</a>
            </div>
            <div class="grid_3">
                <div class="round">71,175</div>
                <div class="text1">Spare desks in shared offices</div>Average cost/mth
                <div class="price col1">$350/person </div>
                from $100/person
                <br>
                <a href="#" class="btn">More</a>
            </div>
            <div class="grid_3">
                <div class="round">271</div>
                <div class="text1">Desks to rent in serviced offices</div>Average cost/mth
                <div class="price col1">$233/person </div>
                from $56/person
                <br>
                <a href="#" class="btn">More</a>
            </div>
        </div>
    </div>
</div>
<!--=====================Content======================-->
<div class="content">
    <div class="gray">
        <div class="container">
            <div class="row">
                <div class="grid_12">
                    <h3>Galeria</h3>
                    <div class="oh">
                        <div class="gallery">
                            <a href="<?php echo $this->assets($theme) ?>images/big1.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img1.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <a href="<?php echo $this->assets($theme) ?>images/big2.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img2.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <a href="<?php echo $this->assets($theme) ?>images/big3.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img3.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <a href="<?php echo $this->assets($theme) ?>images/big4.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img4.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <div class="clear"></div>
                            <a href="<?php echo $this->assets($theme) ?>images/big5.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img5.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <a href="<?php echo $this->assets($theme) ?>images/big6.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img6.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <a href="<?php echo $this->assets($theme) ?>images/big7.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img7.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <a href="<?php echo $this->assets($theme) ?>images/big8.jpg" class="gal">
                                <img src="<?php echo $this->assets($theme) ?>images/page1_img8.jpg" alt="">
                                <div><span class="col1">name: </span>Temporibus autem</div>
                            </a>
                            <div class="clear"></div>
                        </div>                         
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="grid_4">
                <div class="icon">
                    <img src="<?php echo $this->assets($theme) ?>images/icon1.png" alt="">
                    <div class="title col1">Premium services include </div>
                    <ul class="list">
                        <li><a href="#">Receptionist </a></li>
                        <li><a href="#">Full office furniture </a></li>
                        <li><a href="#">Mail services </a></li>
                        <li><a href="#">Conference and board rooms </a></li>
                        <li><a href="#">Personalized telephone answering </a></li>
                    </ul>
                </div>
            </div>
            <div class="grid_4">
                <div class="icon">
                    <img src="<?php echo $this->assets($theme) ?>images/icon2.png" alt="">
                    <div class="title col1">Shared Office Space Resources </div>
                    <ul class="list">
                        <li><a href="#">Office Space &amp; Leasing Info</a></li>
                        <li><a href="#">Office Space Leasing or Buying </a></li>
                        <li><a href="#">Micro Office Solutions Office Space</a></li>
                    </ul>
                </div>
            </div>
            <div class="grid_4">
                <div class="icon">
                    <img src="<?php echo $this->assets($theme) ?>images/icon3.png" alt="">
                    <div class="title col1">Related Articles</div>
                    <ul class="list">
                        <li><a href="#">ISelecting an Office Location</a></li>
                        <li><a href="#">A Beginners Guide to Office Space</a></li>
                        <li><a href="#">Operations / Technology, - Articles</a></li>
                        <li><a href="#">Home Office Essentials</a></li>
                    </ul>
                </div>
            </div>
            <div class="clear"></div>
            <div class="grid_12">
                <h3>Recent Offers</h3>
            </div>
            <div class="grid_3">
                <div class="text2 col1">Co-working:</div>
                <ul class="list1">
                    <li>San Fran...</li>
                    <li>12 desks</li>
                    <li>250 $/m</li>
                </ul>
                <a href="#" class="btn c1">More</a>
            </div>
            <div class="grid_3">
                <div class="text2 col1">Open-plan Office:</div>
                <ul class="list1">
                    <li>Marseill...   </li>
                    <li>8 desks</li>
                    <li>200 €/m   </li>
                </ul>
                <a href="#" class="btn c1">More</a>
            </div>
            <div class="grid_3">
                <div class="text2 col1">Meeting Room:  </div>
                <ul class="list1">
                    <li>Paris</li>
                    <li>8 places </li>
                    <li>2412 €/m</li>
                </ul>
                <a href="#" class="btn c1">More</a>
            </div>
            <div class="grid_3">
                <div class="text2 col1">Closed Office: </div>
                <ul class="list1">
                    <li>Paris</li>
                    <li>16 m2  </li>
                    <li>1680 €/m </li>
                </ul>
                <a href="#" class="btn c1">More</a>
            </div>
            <div class="grid_12">
                <div class="hor"></div>
            </div>
            <div class="bot_block">
                <div class="grid_3"><div class="maxheight">
                        <h4>Telephone</h4>
                        <div class="c_phone col1">+1 800 603 6035</div></div>
                </div>
                <div class="grid_3 ver"><div class="maxheight">
                        <h4>E-Mail Us</h4>
                        <a href="#" class="mail1">mail@demolink.org</a></div>
                </div>
                <div class="grid_3 ver"><div class="maxheight">
                        <h4>Follow Us</h4>
                        <div class="socials">
                            <a href="#" class="fa fa-facebook"></a>
                            <a href="#" class="fa fa-google-plus"></a>
                            <a href="#" class="fa fa-rss"></a>
                            <a href="#" class="fa fa-pinterest"></a>
                            <a href="#" class="fa fa-linkedin"></a>
                        </div></div>
                </div>
                <div class="grid_3 ver">
                    <div class="maxheight">
                        <h4>Address</h4>
                        <address class="add1">9870 St Vincent Place, <br>
                            Glasgow, DC 45 Fr 45.</address></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==============================footer=================================-->
<footer>
    <div class="container">
        <div class="row">
            <div class="grid_12">
                <div class="copy"><strong>copyright</strong> &copy; <span id="copyright-year"></span> <a href="<?php echo $this->createUrl('painel') ?>">Admin</a> <!--{%FOOTER_LINK} -->
                </div>
            </div>
        </div>
    </div>
</footer>
<script src="<?php echo $this->assets($theme) ?>js/jquery.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/jquery-migrate-1.1.1.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/script.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/superfish.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/jquery.equalheights.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/jquery.mobilemenu.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/jquery.easing.1.3.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/tmStickUp.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/jquery.ui.totop.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/touchTouch.jquery.js"></script>
<script src="<?php echo $this->assets($theme) ?>js/camera.js"></script>
<!--[if (gt IE 9)|!(IE)]><!-->
<script src="<?php echo $this->assets($theme) ?>js/jquery.mobile.customized.min.js"></script>

<script type="text/javascript">

    $(document).ready(function(){
        jQuery('#camera_wrap').camera({
            loader: false,
            pagination: false ,
            minHeight: '250',
            thumbnails: false,
            height: '39.3125%',
            caption: false,
            navigation: true,
            fx: 'mosaic'
        });
        $().UItoTop({ easingType: 'easeOutQuart' });
        $('#stuck_container').tmStickUp({});
        $('.gallery a.gal').touchTouch();
    });

    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', '']);
    _gaq.push(['_trackPageview']);
    (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();</script>
</body>
</html>