<?php

/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */

namespace chamado\controllers;

use helps\Session;
use help\User;
use painel\models\Cedente;

class ChamadoController extends \app\Controller {

    private $create = 'http://dev.inetsistemas.com.br/chamado/webservice/createchamado?form_id=1';
    private $form = 'http://dev.inetsistemas.com.br/chamado/webservice/listForm?cliente=marcus@inetsistemas.com.br&form_id=1';
    private $table = 'http://dev.inetsistemas.com.br/chamado/webservice/listTable?clinte=';
    private $tramit = 'http://dev.inetsistemas.com.br/chamado/webservice/listTramit?id=';
    private $tasks = 'http://dev.inetsistemas.com.br/chamado/webservice/createTasks?tramit_id=';

    public function behaviors() {
        return [
            'getClass' => '',
        ];
    }

    public function actionIndex() {

        if (empty(Session::getSession()->id)) {
            return $this->render('login', ['model' => new Cedente()]);
        } else {
            //session_destroy();
            return $this->render('index', ['email' => Session::getSession()->email, 'form_id' => 2]);
        }
    }

    public function actionLogin() {

        Session::setSession([
            'id' => $_GET['id'],
            'email' => $_GET['email'],
            'nome' => $_GET['name'],
        ]);

        header('Location:' . $this->createUrl('chamado'));
        exit;
    }
  public function actionLogout() {

        Session::clear();
        header('Location:' . $this->createUrl('chamado'));
        exit;
    }
    public function actionTramit($id) {

        $url = $this->tramit . $id . '&email=marcus@inetsistemas.com.br';
 
        
        if (!empty($_POST['descricao'])) {

            $campo['Tasks']['descricao'] = $_POST['descricao'];
            $campo['Tasks']['title'] = $_POST['title'];

            $url = $this->tasks . $id . '&email=marcus@inetsistemas.com.br';

            echo $this->setArrayServer($campo, $url);
        } else
            return $this->render('tramit', ['id' => $id, 'model' => $this->getArrayServer($url)]);
    }

    public function actionCreate() {
 
        
        if (!empty($_POST['Chamado']['name']) && !empty($_POST['Chamado']['email'])) {

            $url = $this->create;
            //temos que colocar os parâmetros do post no estilo de uma query string
            echo $this->setArrayServer($_POST, $url);
        } else {
 
            return $this->render('form', ['form' => $this->getArrayServer($this->form), 'nome' => '', 'email' => '']);
        }
    }

    public function getArrayServer($url) {

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

        $output = curl_exec($ch);

        curl_close($ch);

        return json_decode(trim($output), TRUE);
    }

    public function setArrayServer($campos, $url) {

        $ch = curl_init();
        //configurando as opções da conexão curl
        curl_setopt($ch, CURLOPT_URL, $url);
        //este parâmetro diz que queremos resgatar o retorno da requisição
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_POST, count($campos));
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($campos, '', '&'));
        //manda a requisição post
        $resultado = curl_exec($ch);
        curl_close($ch);

        return $resultado;
    }

}
