<?php
$this->title = 'Chamados';

use helps\Url;
use widgets\GridView;
use helps\Session;
 
?>

<div class="module">
    <div class="module-head">
        <h3><?php echo $this->title ?></h3>       

    </div>
    <div class="module-body">

        <br> 
        <table class="table table-striped table-bordered table-condensed dataTable">
            <thead>
                <tr>
                    <th>Solicitante</th>
                    <th>Criação</th>
                    <th>Tick</th>
                    <th>Status</th>                 
                </tr>
            </thead>
            <tfoot></tfoot>
            <tbody>
            </tbody>
        </table>
    </div><!-- /.box-body -->
</div><!-- /.box-body -->  

<script>


    ﻿$(document).ready(function () {

        $.post('http://dev.inetsistemas.com.br/chamado/webservice/listTable?clinte=<?php echo $email ?>&form_id=<?php echo $form_id ?>', function (data) {
            var i = 0;
            var thead = $('thead tr');
            for (; i < data.thead.length; ++i) {
                thead.append("<th>" + data.thead[i] + "</th>");
            }
            thead.append("<th>Ação</th>");

                $('.dataTable').dataTable({
                "ajax": 'http://dev.inetsistemas.com.br/chamado/webservice/listTable?clinte=<?php echo $email ?>&form_id=<?php echo $form_id ?>',
                "columnDefs":[{
                        "targets": -1,
                        "render": function ( data, type, row ) {
                            return '<a href="<?php echo Url::base('tramit')?>/'+row['id']+'"><i class="icon-edit shaded"></i></a>';
                        },
                    }
                       ],
                "language": {
                    "sEmptyTable": "Nenhum registro encontrado",
                    "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
                    "sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
                    "sInfoFiltered": "(Filtrados de _MAX_ registros)",
                    "sInfoPostFix": "",
                    "sInfoThousands": ".",
                    "sLengthMenu": "_MENU_ resultados por página",
                    "sLoadingRecords": "Carregando...",
                    "sProcessing": "Processando...",
                    "sZeroRecords": "Nenhum registro encontrado",
                    "sSearch": "Pesquisar",
                    "oPaginate": {
                        "sNext": "Próximo",
                        "sPrevious": "Anterior",
                        "sFirst": "Primeiro",
                        "sLast": "Último"
                    }
                },
            });
 

            $('.dataTables_paginate').addClass('btn-group datatable-pagination');
            $('.dataTables_paginate > a').wrapInner('<span />');
            $('.dataTables_paginate > a:first-child').append('<i class="icon-chevron-left shaded"></i>');
            $('.dataTables_paginate > a:last-child').append('<i class="icon-chevron-right shaded"></i>');

        }, 'JSON');

    });


</script>