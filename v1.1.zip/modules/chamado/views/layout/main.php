<?php

use helps\Session;
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $this->title ?></title>
        <link  href="<?php echo $this->assets($theme) ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link  href="<?php echo $this->assets($theme) ?>bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link  href="<?php echo $this->assets($theme) ?>css/theme.css" rel="stylesheet">
        <link  href="<?php echo $this->assets($theme) ?>images/icons/css/font-awesome.css" rel="stylesheet">
        <link  href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
        <script src="<?php echo $this->assets($theme) ?>scripts/jquery-1.9.1.min.js" ></script>
        <script>
        
            
           var Alert =  function(Class,msg){
            
            setTimeout(function(){
                
                $('#Alert .alert').fadeOut("slow");
                $('#Alert .alert').removeClass(Class);
                
            },3000);
            window.scrollTo(3000, 0);
            $('#Alert .alert strong').html('');
            $('#Alert .alert').fadeIn();
            $('#Alert .alert').addClass('alert-'+Class);
            $('#Alert .alert strong').html(msg);
        };
            
            
        
        
        </script>
    </head>
    <body>
        <div id="Alert">
            <div class="alert" style="display: none" >
            <strong></strong>
            </div>
        </div>
        <div class="navbar navbar-fixed-top">
            
            <div class="navbar-inner">
                <div class="container" style="margin-top:50px;">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a><a class="brand" href="<?php echo $this->createUrl() ?>">Voltar </a>
                    <div class="nav-collapse collapse navbar-inverse-collapse">
                        <!--
                        <ul class="nav nav-icons">
                            <li class="active"><a href="#"><i class="icon-envelope"></i></a></li>
                            <li><a href="#"><i class="icon-eye-open"></i></a></li>
                            <li><a href="#"><i class="icon-bar-chart"></i></a></li>
                        </ul>
                        
                        <form class="navbar-search pull-left input-append" action="#">
                            <input type="text" class="span3">
                            <button class="btn" type="button">
                                <i class="icon-search"></i>
                            </button>
                        </form>
                       -->
                         
                    </div>
                        <ul class="nav pull-right">
                                <li class=""><a href="<?php echo $this->createUrl('chamado/create') ?>"><i class="menu-icon icon-dashboard"></i>Abrir Chamado</a></li>
                               
                                <?php 
                                
                                if(!empty(Session::getSession()->id)):
                                ?>
                                <li><a href="<?php echo $this->createUrl('chamado/logout') ?>"><i class="menu-icon icon-exchange"></i>Sair</a></li>                            
                                <?php
                                endif;
                                ?>
                                
                        </ul>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>
        <!-- /navbar -->
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    
                    <!--/.span3-->
                    <div class="span12">
                        <div class="content">
                            <?php echo $content ?>
                        </div>
                        <!--/.content-->
                    </div>
                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>
        <!--/.wrapper-->
        <div class="footer">
            <div class="container">

            </div>
        </div>

        <script src="<?php echo $this->assets($theme) ?>scripts/jquery-ui-1.10.1.custom.min.js" ></script>
        <script src="<?php echo $this->assets($theme) ?>bootstrap/js/bootstrap.min.js" ></script>
        <script src="<?php echo $this->assets($theme) ?>scripts/flot/jquery.flot.js" ></script>
        <script src="<?php echo $this->assets($theme) ?>scripts/flot/jquery.flot.resize.js" ></script>
        <script src="<?php echo $this->assets($theme) ?>plugins/datatables/datatable.js" ></script>
        <script src="<?php echo $this->assets($theme) ?>scripts/common.js" ></script>
    </body>
</html>