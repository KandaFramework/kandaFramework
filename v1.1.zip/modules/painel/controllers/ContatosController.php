<?php
/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */
namespace painel\controllers;

use painel\models\Contato;
use help\User;
 

class ContatosController extends \app\Controller {
    
    public function behaviors() {
        return [
            'getClass' => User::rule(),
        ];
    }
    
    public function actionIndex() {
         
        return $this->render('index', ['dataProvider' => Contato::dataProvider() ]);
    }
    
    public function actionUpdate($id){
                 
      return $this->render('form', ['model' => $this->findModel($id)]);
        
    }
    public function actionDelete($id) {
        
    if(isset($id) && !empty($id)){
                $model =  $this->findModel($id);
          if($model->delete()){
            
              \Kanda::setflash('delete','Deletado com sucesso');
              
            return $this->redirect();
              
            }
        }        
    }   
    
    public function actionGerarcsv($tipo=1){
         
        $model = Contato::find('all',['conditions'=>"tipo=$tipo"]);
          
        $csv = "nome;email;telefone;mensagem;criacao\n";
          
        foreach($model as $data)             
           $csv .= "{$data->nome};{$data->email};{$data->telefone};{$data->mensagem};".date('Y-m-d H:i:s',  strtotime($data->criacao))."\n";
   
        echo utf8_encode($csv); 
         
      #header('Content-type:application/csv');
         
      #header('Content-Disposition: attachment; filename="downloaded.csv"');
         
    }
    
    public function findModel($id){
        
        if(!empty($id)){
            $model = Contato::find($id);
            return $model;
        }
    }
       
}