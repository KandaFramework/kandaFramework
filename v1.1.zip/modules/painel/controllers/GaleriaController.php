<?php

/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */

namespace painel\controllers;

use helps\UploadFile;
use vendor\wideImage\WideImage;
use painel\models\Galeria;
use help\User;

class GaleriaController extends \app\Controller {

    public function behaviors() {
        return [
            'getClass' => User::rule(),
        ];
    }

    public function actionIndex() {

        $model = new Galeria();

        $file = UploadFile::load($model, 'file');

        if (!empty($file->name)) {


            $widget = WideImage::load($file->tmpName);

            $small = $widget->resize(279, 191);
            $big = $widget->resize(800, 509);

            $name = $this->Formart($file->name);

            $small->saveToFile($this->dirName('279x191') . $name);
            $big->saveToFile($this->dirName('800x509') . $name);
             

            $model->file = $name;
            $model->name_alias = $file->name;
            $model->size = $file->size;
            $model->type = $file->type;


            if ($model->save()) {
                $this->Json([
                    'success' => 'Enviado com sucesso!',
                ]);
            }
        } else
            return $this->render('index', ['model' => $model]);
    }

    public function actionUpdate($id) {

        return $this->render('form', ['model' => $this->findModel($id)]);
    }

    public function actionDelete($id) {

        if (isset($id) && !empty($id)) {
            $model = $this->findModel($id);
            if ($model->delete()) {

                \Kanda::setflash('delete', 'Deletado com sucesso');

                return $this->redirect();
            }
        }
    }

    public function findModel($id) {

        if (!empty($id)) {
            $model = Galeria::find($id);
            return $model;
        }
    }

    public static function dirName($dirAlias) {

        return WWW_ROOT . "/web/anexojob/assets/images/galeria/$dirAlias/";
    }

}
