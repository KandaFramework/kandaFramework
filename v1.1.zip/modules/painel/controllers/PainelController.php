<?php

/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */

namespace painel\controllers;

use painel\models\Usuario;
use helps\Session;

class PainelController extends \app\Controller {

    public function actionIndex() {
 
        
        $model = new Usuario;
        
        if (empty(Session::getSession()->id)) {
            
            $this->layout = 'login';
            session_destroy();
            $this->render('login',['model'=>$model]);
             
        } else {
            return $this->render('index');
        }
    }

    public function actionLogaout() {

        session_destroy();
        return header('Location:' . $this->createUrl('painel'));
    }

}
