<?php
/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */
namespace painel\controllers;
use helps\UploadFile;
use painel\models\Slide;
use help\User;


class SlideController extends \app\Controller {
    
    public function behaviors() {
        return [
            'getClass' => User::rule(),
        ];
    }
    
    public function actionIndex() {
                
        $model = new Slide();
                
        $file = UploadFile::load($model,'file');

        if(!empty($file->name)){
 
            
            $name = $this->Formart($file->name);

            $model->file = $name;
            $model->name_alias = $file->name;
            $model->size = $file->size;
            $model->type = $file->type;
             
            if(!$file->saveAs($this->dirName().$name))
                $this->Json ([
                    'error'=>'Erro para enviar arquivo!', 
                ]);

            if($model->save()){
                $this->Json([
                    'success'=>'Enviado com sucesso!',
                ]);
            }
                
        }else       
            return $this->render('index', ['model' => $model ]);
    }
    
    public function actionUpdate($id){
                 
      return $this->render('form', ['model' => $this->findModel($id)]);
        
    }
    
    public function actionDelete($id) {
        
    if(isset($id) && !empty($id)){
                $model =  $this->findModel($id);
          if($model->delete()){
            
              \Kanda::setflash('delete','Deletado com sucesso');
              
            return $this->redirect();
              
            }
        }        
    }   
        
    public function findModel($id){
        
        if(!empty($id)){
            $model = Slide::find($id);
            return $model;
        }
    }
    
    public static function dirName(){

        return WWW_ROOT.'/web/anexojob/assets/images/';

    }
       
}