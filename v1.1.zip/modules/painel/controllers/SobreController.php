<?php

/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */

namespace painel\controllers;

use painel\models\Sobre;
use helps\Session;

class SobreController extends \app\Controller {

    public function actionIndex() {
  
        $model = new Sobre;
         
        
        if (\Kanda::$request->post($model)) {
           
        // $model->usuario_user_id = \Kanda::$app->session->getSession()->id;
         
        $this->findModel(3)->update_attributes(['descricao'=>$model->descricao]);   
        
        $this->Json([
                'text' => 'Alterado com sucesso', 
        ]);
        
        
        } else {
            return $this->render('index',['model'=>  $this->findModel(3)]);
        }
    }
    
    public function findModel($id) {

        if (!empty($id)) {
            $model = Sobre::find($id);
            return $model;
        }
    }
}
