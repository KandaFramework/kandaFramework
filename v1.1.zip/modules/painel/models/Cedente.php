<?php

/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */

namespace painel\models;

class Cedente {

    public static function rules() {

        return [
            [['email', 'tickt'], 'required'],
        ];
    }
}
