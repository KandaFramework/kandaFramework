<?php 
/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */
namespace painel\models;

class Contato extends \ActiveRecord\Model {

    static $table_name = 'contato';
    static $primary_key = 'id';
   
     public static function rules() {

        return [
                 [['nome','telefone','status'],'required'],
                 ['email','email','required','message'=>'Obrigatório','error'=>'Email inválido'],
                 [['mensagem'],'varchar'],
        ];
    }   
    
    public static function attributeLabels(){
        
        return [
            'nome' => 'Nome',
            'email' => 'E-mail',
            'telefone' => 'Telefone',
            'mensagem' => 'Mensagem',  
            'assunto' => "Assunto",
            'status'=>'Status',
            'cri'=>'Criação'
        ];
    }
    
    public static function dataProvider($tipo=1){
     
    return array_merge(
                       ['data'=>  parent::find('all',['conditions'=>"tipo=$tipo",'select'=>"nome,id,email,status,telefone,date_format(criacao,'%d-%m-%Y as %H:%i') cri"]),],
                       Contato::attributeLabels(),['primary_key'=>parent::$primary_key, ]
            );
             
    }
}