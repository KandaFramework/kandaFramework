<?php 
/**
 * @copyright (c) KandaFramework
 * @access public
 * 
 * 
 */
namespace painel\models;

class Galeria extends \ActiveRecord\Model {

    static $table_name = 'galeria';
    static $primary_key = 'id';
   
     public static function rules() {

        return [
                 [['title','ordem'],'required'], 
                 ['file', 'file', 'required','extension'=>"png|jpg", 'message' => 'Obrigatório', 'error' => 'Somente png, jpg'],
        ];
    }   
    
    public static function attributeLabels(){
        
        return [
            'title' => 'Nome',  
            'file' =>'Foto: Dimensão:800x509. Formato:png|jpg',
        ];
    }
    
    public static function dataProvider(){
     
    return array_merge(
                       ['data'=> parent::find('all',['select'=>"title,description"]),],
                       self::attributeLabels(),['primary_key'=>self::$primary_key, ]
            );
             
    }
}