<?php
/**
 * Created by PhpStorm.
 * User: thiago
 * Date: 12/05/15
 * Time: 14:03
 */

namespace painel\models;


class Sobre  extends \ActiveRecord\Model {

    static $table_name = 'sobre';
    static $primary_key = 'id';

    public static function rules() {

        return [
            [['descricao'],'varchar'],
        ];
    }

    public static function attributeLabels() {

        return [
            'name' => 'Nome',
            'id'  => 'Código'
        ];
    }

    public static function dataProvider(){

        return array_merge(
            ['data'=>self::find('all',['select'=>'id,name'])],
            self::attributeLabels(),['primary_key'=>  self::$primary_key, ]
        );

    }

}