<?php
$this->title = "Calendário";
?>
<div style="position: relative;margin-top: 50px;width: 100%;height: 100%" class="calendar"></div>

<link href="<?php echo $this->assets($theme) ?>css/fullcalendar.css" rel="stylesheet" />
<link href="<?php echo $this->assets($theme) ?>css/fullcalendar.print.css" media='print' rel="stylesheet" type="text/css">

<script src='<?php echo $this->assets($theme) ?>js/vendor/fullcalendar/lib/moment.min.js'></script>
<script src='<?php echo $this->assets($theme) ?>js/vendor/fullcalendar/fullcalendar.min.js'></script>
<script src='<?php echo $this->assets($theme) ?>js/vendor/fullcalendar/lang-all.js'></script>
<script>
 
$(document).ready(function () {

    /**
     * FullCalendar 
     **/
    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();

    var calendar = $('.calendar').fullCalendar({
        lang: 'pt-br',
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        },
        // defaultView:'agendaWeek',
        events: [
			{
				title: 'All Day Event',
				start: new Date(y, m, 1)
			},
			{
				title: 'Long Event',
				start: new Date(y, m, d-5),
				end: new Date(y, m, d-2)
			},
			{
				id: 999,
				title: 'Repeating Event',
				start: new Date(y, m, d-3, 16, 0),
				allDay: false
			},
			{
				id: 999,
				title: 'Repeating Event',
				start: new Date(y, m, d+4, 16, 0),
				allDay: false
			},
			{
				title: 'Meeting',
				start: new Date(y, m, d, 10, 30),
				allDay: false
			},
			{
				title: 'Lunch',
				start: new Date(y, m, d, 12, 0),
				end: new Date(y, m, d, 14, 0),
				allDay: false
			},
			{
				title: 'Birthday Party',
				start: new Date(y, m, d+1, 19, 0),
				end: new Date(y, m, d+1, 22, 30),
				allDay: false
			},
			{
				title: 'Click for Google',
				start: new Date(y, m, 28),
				end: new Date(y, m, 29),
				url: 'http://google.com/'
			}
		],
        // Convert the allDay from string to boolean
        eventRender: function (event, element, view) {
            if (event.allDay === 'true') {
                event.allDay = true;
            } else {
                event.allDay = false;
            }
        },
        selectable: false,
        selectHelper: false,
        select: function (start, end, allDay) {

            var data = moment(start).format('YYYY-MM-DD');

            $("#myModal").html('');
            $("#eventContent").click();

            $("#myModal").append(Form('', '', '', '', '#ebebeb', permission));

            $('#SalverEvent').click(function () {

                var title = $('#title').val();
                var descricao = $('#descricao').val();
                var start = data + " " + $('#start').val();
                var end = data + " " + $('#end').val();
                var color = $('#resColor').val();

                var param = {title: title, start: start, end: end, descricao: descricao, color: color};

                $.ajax({
                    url: '/backend/web/calendario/create',
                    data: param,
                    type: "POST",
                    dataType: 'json',
                    success: function (data) {

                        Alert(data.text, data.class, 2000, true);

                        calendar.fullCalendar('renderEvent',
                                {
                                    title: title,
                                    start: start,
                                    end: end,
                                    descricao: descricao,
                                    color: data.color,
                                    id: data.id,
                                }, true
                                );
                    },
                });

            });

        },
        editable: false,
        eventDrop: function (event, delta) {

            var start = moment(event.start).format('YYYY-MM-DD h:mm:ss');
            var end = moment(event.end).format('YYYY-MM-DD h:mm:ss');

            var param = {start: start, end: end, id: event.id};

            AjaxFunctionNull('/backend/web/calendario/drop',param);
            
        },
        eventResize: function (event) {

            var start = moment(event.start).format('YYYY-MM-DD h:mm:ss');
            var end = moment(event.end).format('YYYY-MM-DD h:mm:ss');

            var param = {start: start, end: end, id: event.id};

            AjaxFunctionNull('/backend/web/calendario/drop',param);

        },
        eventClick: function (event, jsevent, view) {

            $("#myModal").html('');
            $("#eventContent").click();

            var start = moment(event.start).format('H:mm');
            var end = moment(event.end).format('H:mm');

            $("#myModal").append(Form(event.title, event.descricao, event.date_start, event.date_end, event.color, permission,event.local));

            var obj = $(this);

            $('#DeleteEvento').click(function(){
              
               var param = {id: event.id};
              
               $.ajax({
                url: '/backend/web/calendario/delete',
                data: param, type: "POST", dataType: 'json',
                success: function (data) {                
                Alert(data.text, data.class, 3000, true); 
                
                calendar.fullCalendar('refetchEvents');
               }
               });
            });
               
            $('#SalverEvent').click(function () {

                var title = $('#title').val();
                var descricao = $('#descricao').val();
                var color = $('#resColor').val();

                start = event.date_start + " " + $('#start').val();
                end = event.date_end + " " + $('#end').val();

                var id = event.id;

                var param = {title: title, start: start, end: end, descricao: descricao, id: id, color: color};

                $.ajax({
                    url: '/backend/web/calendario/update',
                    data: param,
                    type: "POST",
                    dataType: 'json',
                    success: function (data) {

                        Alert(data.text, data.class, 3000, false);

                        calendar.fullCalendar('refetchEvents');

                        obj.fadeIn();

                    },
                });

            });
        }
    });
});
</script>