<?php
$this->title = "INETSISTEMAS :: CONTATOS";
?>
<div class="box span12">
    <div data-original-title="" class="box-header">
        <h2><i class="icon-reorder"></i><span class="break"></span></h2>
        <div class="box-icon">
            <a class="btn-setting" href="#"><i class="halflings-icon wrench"></i></a>
            <a class="btn-minimize" href="#"><i class="halflings-icon chevron-up"></i></a>
            <a class="btn-close" href="#"><i class="halflings-icon remove"></i></a>
        </div>
    </div>
    <br/>
    <table class="table table-striped table-bordered bootstrap-datatable  datatable dataTable">
        <thead>
            <tr role="row">
                <th>ID</th>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Mensagem</th>
                <th>Ação</th>
            </tr>    
        </thead>   

        <tbody role="alert" aria-live="polite" aria-relevant="all">
<?php
$User = $model->find('all');

foreach ($User as $contato) {
    ?>
                <tr class="odd">
                    <td class="center"><?php echo $contato->id ?></td>
                    <td class="  sorting_1"><?php echo $contato->nome ?></td>
                    <td class="  sorting_1"><?php echo $contato->email ?></td>
                    <td class="center "><?php echo $contato->telefone ?></td>
                    <td class="center "><?php echo $contato->data_criacao ?></td>
                    <td class="center ">
                        <a href="contatos/view?id=<?php echo $contato->id ?>" title="Visualizar" class="btn btn-success">
                            <i class="halflings-icon white zoom-in"></i>  
			</a>
                        <a href="contatos/delete?id=<?php echo $contato->id ?>" class="btn btn-danger">
                            <i class="halflings-icon white trash"></i> 
                        </a>
                    </td>
                </tr>              
    <?php
    }
?>                                                   
        </tbody>
    </table>
</div>