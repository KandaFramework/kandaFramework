<?php
use helps\Html;
$this->title = "Visualizar contato!";
?>
<div class="box span12">
            <div data-original-title="" class="box-header">
                <h2><i class="icon-reorder"></i><span class="break"></span></h2>
                <div class="box-icon">
                    <a class="btn-setting" href="#"><i class="halflings-icon wrench"></i></a>
                    <a class="btn-minimize" href="#"><i class="halflings-icon chevron-up"></i></a>
                    <a class="btn-close" href="#"><i class="halflings-icon remove"></i></a>
                </div>
            </div>

    <div class="box-content">
        <?php
        echo Html::a('Voltar','/kandaFramework/painel/contatos',['class'=>'btn btn-info']);
        ?>
        <br/>
        <form class="form-horizontal">
            <div class="control-group">
            <label  class="control-label">Nome</label>
            <div class="controls">
                  <input type="text" value="<?php echo $model->nome ?>" class="input-xlarge datepicker hasDatepicker">
            </div>
          </div>
            <div class="control-group">
            <label  class="control-label">E-mail</label>
            <div class="controls">
                  <input type="text" value="<?php echo $model->email ?>" class="input-xlarge datepicker hasDatepicker">
            </div>
          </div>
            <div class="control-group">
            <label  class="control-label">Telefone</label>
            <div class="controls">
                  <input type="text" value="<?php echo $model->telefone ?>" class="input-xlarge datepicker hasDatepicker">
            </div>
          </div>
            <div class="control-group">
            <label  class="control-label">Mensagem</label>
            <div class="controls">
                <textarea><?php echo $model->mensagem ?></textarea>
            </div>
          </div>
        </form>
    </div>
</div>
