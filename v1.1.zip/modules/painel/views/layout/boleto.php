<?php
require WWW_ROOT.'/vendor/mpdf/mpdf.php';
 
$mpdf=new mPDF('c','A4'); 

$mpdf->SetDisplayMode('fullpage');
//
$mpdf->WriteHTML($content);
$mpdf->Output();
exit;