<?php
$this->title = 'INETSISTEMAS :: NOTICIAS';

use widgets\GridView;
use helps\Url;
?>
<div class="box span12">
    <div data-original-title="" class="box-header">
        <h2><i class="icon-reorder"></i><span class="break"></span></h2>
        <div class="box-icon">
            <a class="btn btn-info create" href="<?php echo Url::base() ?>">voltar</a> 
            <a class="btn btn-success create" href="<?php echo Url::base('newslettercreate') ?>">cadastrar</a>            
                       
        </div>
    </div>

    <div class="box-content">
        
        <?php
      
       echo GridView::widget([
            'dataProvider' => $dataProvider,
            'columns' => [
                'nome',                
                'status',
            ],
            'actionColumns'=>['update','delete'],
        ]);       
        echo Kanda::$app->session->getflash('delete');
        echo Kanda::$app->session->getflash('create');
       
        ?>
    </div>
</div>