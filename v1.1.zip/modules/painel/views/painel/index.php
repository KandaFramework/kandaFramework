<?php
$this->title = "INETSISTEMAS :: Dashboard";

use backend\controllers\painel\DashboardController;

use helps\Url;
?>
<div class="box-content">

    <a class="quick-button span2" href="<?php echo Url::home('usuarios')?>">
        <i class="icon-group"></i>
        <p>Usuarios</p>
<!--        <span class="notification blue">1.367</span>-->
    </a>
    <a class="quick-button span2"href="<?php echo Url::home('contatos')?>">
        <i class="icon-comments-alt"></i>
        <p>Contatos</p>
<!--        <span class="notification green">167</span>-->
    </a>
    <a class="quick-button span2" href="<?php echo Url::home('clientes')?>">
        <i class="icon-shopping-cart"></i>
        <p>Clientes</p>
    </a>
    <a class="quick-button span2" href="#">
        <i class="icon-barcode"></i>
        <p>Produtos</p>
    </a>
    <a class="quick-button span2" href="<?php echo Url::home('chamado')?>">
        <i class="icon-hand-up"></i>
        <p>Chamados</p>
    </a>
    <a class="quick-button span2" href="<?php echo Url::home('calendario')?>">
        <i class="icon-calendar"></i>
        <p>Calendario</p>         
    </a>
    <div class="clearfix"></div>
</div>