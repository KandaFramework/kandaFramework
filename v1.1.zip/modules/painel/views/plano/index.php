<?php
$this->title = 'INETSISTEMAS :: PLANOS';

use widgets\GridView;
use helps\Html;
use helps\Url;
?>
<div class="box span12">
    <div data-original-title="" class="box-header">
        <h2><i class="icon-reorder"></i><span class="break"></span></h2>
        <div class="box-icon">
            <div class="box-icon">
                <a class="btn btn-warning create" href="<?php echo Url::base('create') ?>">cadastrar</a>            
            </div>
        </div>
    </div>

    <div class="box-content">

        <?php
        echo GridView::widget([
            'dataProvider' => $dataProvider,
            'columns' => [
                'nome',
                'valor' => [
                            'header' => 'Valor',
                            'container' => function($model, $key) {
                               return number_format($model->valor, 2, ',', '');;
                            } 
                        ],
                'subplanos' => [
                    'header' => 'Sub Planos',
                    'container' => function($model, $key) {

                        return Html::a('<i></i>', Url::base("subplanos?id=$key"), ['class' => 'glyphicons coins']);
                    }
                        ],
                        'destaque' => [
                            'header' => 'Em destaque',
                            'container' => function($model, $key) {
                                return ($model->destaque == 1) ? Html::a('Sim', '#', ['class' => 'btn btn-success']) : Html::a('Nao', '#', ['class' => 'btn btn-danger']);
                            }
                                ],
                            ],
                            'actionColumns' => ['update', 'delete'],
                        ]);

                        echo Kanda::$app->session->getflash('create');
                        echo Kanda::$app->session->getflash('delete');
                        ?>
    </div>
</div>