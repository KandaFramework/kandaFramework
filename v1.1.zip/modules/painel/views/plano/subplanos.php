<?php
$this->title = 'INETSISTEMAS :: PLANOS';

use widgets\GridView;
use helps\Url;
?>
<div class="box span12">
    <div data-original-title="" class="box-header">
        <h2><i class="icon-reorder"></i><span class="break"></span></h2>
        <div class="box-icon">
            <a class="btn btn-info create" href="<?php echo Url::base() ?>">voltar</a>            
            <a class="btn btn-success create" href="<?php echo Url::base("subplanoscreate?id=" . $_GET['id']) ?>">cadastrar</a>            
        </div>
    </div>

    <div class="box-content">
        <?php
        echo GridView::widget([
            'dataProvider' => $dataProvider,
            'columns' => [
                'nome',
                'valor',
            ],
            'actionColumns' => [

                'update' => [
                    'container' => function($id) {
                        return "<a href='" . Url::base("subplanosupdate?id=" . $id . "&param=" . $_GET['id']) . "'   class='btn btn-info'>
                                <i class='halflings-icon white edit'></i>  
                            </a>";
                    }
                ],
                'delete' => [
                    'container' => function($id) {
                        return "<a href='" . Url::base("subplanosdelete?id=" . $id . "&param=" . $_GET['id']) . "' onclick=\" if(confirm('Deseja excluir esse item?')){return true;}else{return false;};\" class='btn btn-danger'>
                                <i class='halflings-icon white trash'></i>  
                            </a>";
                    }
                ],
            ],
        ]);

        echo Kanda::$app->session->getflash('subCreate');
        echo Kanda::$app->session->getflash('delete');
        ?>
    </div>
</div>