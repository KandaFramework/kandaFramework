<?php
$this->title = "INETSISTEMAS :: SLIDES";

use helps\Url;
use widgets\FormWidget;
?> 
<link rel="stylesheet" href="<?php echo $this->assets('anexojob') ?>css/camera.css">
<div class="box span12">
    <div data-original-title="" class="box-header">
        <h2><i class="icon-reorder"></i><span class="break"></span></h2>
        <div class="box-icon">
            <a class="btn-setting" href="#"><i class="halflings-icon wrench"></i></a>
            <a class="btn-minimize" href="#"><i class="halflings-icon chevron-up"></i></a>
            <a class="btn-close" href="#"><i class="halflings-icon remove"></i></a>
        </div>
    </div>
    <div class="box-content">
        <form method="POST"  action="<?php echo Url::request() ?>" class="form-horizontal" enctype="multipart/form-data" >
            <fieldset>
                <?php
                $form = FormWidget::widget($model, [
                ]);

                echo $form->fileFieldGroup('file',['multiple'=>3]);
                ?>
                <div style="margin-bottom: 9px;" class="progress progress-striped active fileUpload">
                    <div style="" class="bar"></div>
                </div>
            </fieldset>
        </form>


        <div class="slider_wrapper ">
            <div id="camera_wrap" class="">
                <?php
                                foreach ($model->all() as $data):
                ?>
                <div data-src="<?php echo $this->assets('anexojob') ?>images/<?php echo $data->name_alias ?>">
                    <div class="caption fadeIn">
                        <h2><span>We'll find</span>your dream</h2>
                        office in minutes
                    </div>
                </div>
                <?php
                endforeach;
                ?>                 
            </div>
        </div>


    </div> 
</div>
<script src="<?php echo $this->assets('anexojob') ?>js/camera.js"></script>
<script src="<?php echo $this->createUrl() ?>/vendors/fileupload/js/vendor/jquery.ui.widget.js"></script>
<script src="<?php echo $this->createUrl() ?>/vendors/fileupload/js/jquery.iframe-transport.js"></script>
<script src="<?php echo $this->createUrl() ?>/vendors/fileupload/js/jquery.fileupload.js"></script>
<script>
    $(document).ready(function () {
        jQuery('#camera_wrap').camera({
            loader: false,
            pagination: false,
            minHeight: '250',
            thumbnails: false,
            height: '39.3125%',
            caption: false,
            navigation: true,
            fx: 'mosaic'
        });
    });
    $(function () {
        $('#file').fileupload({
            dataType: 'json',
            progressall: function (e, data) {
                $('.progress .bar').css('width', '0%');

                var progress = parseInt(data.loaded / data.total * 100, 10);
                $('.progress .bar').css(
                        'width',
                        progress + '%'
                        );
            },
            done: function (e, data) {

                $('.progress .bar').css('width', '0%');

                var li = '<li><a href="' + data.result.delete + '"><i class="halflings-icon trash"></i><a href="' + data.result.url + '"> ' + data.result.name + '</a></li>';
                $('#ListFiles').append(li);

            }
        });
    });
</script>
