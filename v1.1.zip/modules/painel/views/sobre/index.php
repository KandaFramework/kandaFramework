<?php
$this->title = 'INETSISTEMAS :: SOBRE'; 
?>
<style>
.cleditorMain{
   width: 1050px !important;
}
.row-fluid .span12 {
    margin-left: 5px;    
}
</style>
<div class="box span12">
    <div data-original-title="" class="box-header">
        <h2><i class="icon-reorder"></i><span class="break"></span></h2>
        <div class="box-icon">
            <a class="btn-setting" href="#"><i class="halflings-icon wrench"></i></a>
            <a class="btn-minimize" href="#"><i class="halflings-icon chevron-up"></i></a>
            <a class="btn-close" href="#"><i class="halflings-icon remove"></i></a>
        </div>
    </div>

    <div class="box-content">        
        <form name="Sobre" id="Sobre" method="POST" >
          <textarea  rows="3" id="textarea2" name="Sobre[descricao]" class="cleditor" style="display: none;">
                                            <?php echo $model->descricao ?>
        </textarea><br/>
            <button class="btn btn-info " type="button" onclick="post()">Atualizar</button>
        </form>        
    </div>    
</div>
<?php
  echo \app\View::post('/painel/sobre/update','Sobre');

