<?php

echo $content;